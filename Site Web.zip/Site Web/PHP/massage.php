<?php
session_start();
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "salon_de_coiffure";

// Créer la connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'La connexion a échoué: ' . $conn->connect_error]);
    exit();
}

// Gestion des requêtes POST pour les opérations CRUD
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $designation = $_POST['designation'];
                $prix = $_POST['prix'];
                $image = '';

                if (isset($_FILES['imageFile']) && $_FILES['imageFile']['error'] == 0) {
                    $image = 'uploads/' . basename($_FILES['imageFile']['name']);
                    if (!move_uploaded_file($_FILES['imageFile']['tmp_name'], __DIR__ . '/' . $image)) {
                        echo json_encode(['error' => 'Erreur lors du téléchargement du fichier.']);
                        exit();
                    }
                } else {
                    $image = $_POST['imageUrl'];
                }

                $query = "INSERT INTO prestations (designation, prix, image) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('sss', $designation, $prix, $image);

                if ($stmt->execute()) {
                    $prestations_id = $stmt->insert_id;
                    $query = "INSERT INTO massage (id) VALUES (?)";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param('i', $prestations_id);

                    if ($stmt->execute()) {
                        echo json_encode(['message' => 'Nouvelle massage ajoutée avec succès.']);
                    } else {
                        echo json_encode(['error' => 'Erreur lors de l\'ajout dans la table massage: ' . $stmt->error]);
                    }
                } else {
                    echo json_encode(['error' => 'Erreur lors de l\'ajout dans la table prestations: ' . $stmt->error]);
                }
                $stmt->close();
                break;
            
            case 'update':
                $id = $_POST['id'];
                $designation = $_POST['designation'];
                $prix = $_POST['prix'];
                $image = ''; // Initialiser l'image

                // Récupérer l'image actuelle de la base de données
                $query = "SELECT image FROM prestations WHERE id=?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('i', $id);
                
                if ($stmt->execute()) {
                    $result = $stmt->get_result();
                    $row = $result->fetch_assoc();
                    $currentImage = $row['image'];
                    $stmt->close();
                } else {
                    echo json_encode(['error' => 'Erreur lors de la récupération de l\'image actuelle: ' . $stmt->error]);
                    exit();
                }

                // Vérifier si une nouvelle image a été téléchargée depuis l'ordinateur
                if (isset($_FILES['imageFile']) && $_FILES['imageFile']['error'] == 0) {
                    $image = 'uploads/' . basename($_FILES['imageFile']['name']);
                    if (!move_uploaded_file($_FILES['imageFile']['tmp_name'], __DIR__ . '/' . $image)) {
                        echo json_encode(['error' => 'Erreur lors du téléchargement du fichier.']);
                        exit();
                    }
                } elseif (!empty($_POST['imageUrl'])) {
                    // Vérifier si une nouvelle URL d'image a été fournie
                    $image = $_POST['imageUrl'];
                } else {
                    // Conserver l'ancienne image si aucune nouvelle image n'est fournie
                    $image = $currentImage;
                }

                $query = "UPDATE prestations SET designation=?, prix=?, image=? WHERE id=?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('sssi', $designation, $prix, $image, $id);

                if ($stmt->execute()) {
                    echo json_encode(['message' => 'massage mise à jour avec succès.']);
                } else {
                    echo json_encode(['error' => 'Erreur lors de la mise à jour: ' . $stmt->error]);
                }
                $stmt->close();
                break;

            case 'delete':
                $id = $_POST['id'];

                $query = "DELETE FROM massage WHERE id=?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('i', $id);

                if ($stmt->execute()) {
                    $query = "DELETE FROM prestations WHERE id=?";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param('i', $id);

                    if ($stmt->execute()) {
                        echo json_encode(['message' => 'massage supprimée avec succès.']);
                    } else {
                        echo json_encode(['error' => 'Erreur lors de la suppression de la prestation: ' . $stmt->error]);
                    }
                } else {
                    echo json_encode(['error' => 'Erreur lors de la suppression de la massage: ' . $stmt->error]);
                }
                $stmt->close();
                break;
        }
        exit();
    }
}

// Récupérer les massages et vérifier les likes
$utilisateur_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    
    // Préparer la requête SQL pour la recherche
    $query = "
        SELECT p.id, p.designation, p.prix, p.image, 
               (SELECT COUNT(*) FROM likes WHERE utilisateur_id = ? AND prestation_id = p.id) > 0 AS isLiked 
        FROM massage AS c 
        JOIN prestations AS p ON c.id = p.id
        WHERE p.designation LIKE ? OR p.prix LIKE ?
    ";
    $stmt = $conn->prepare($query);
    $searchTerm = "%$search%";
    $stmt->bind_param("iss", $utilisateur_id, $searchTerm, $searchTerm);
    
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $massages = [];

        while ($row = $result->fetch_assoc()) {
            $massages[] = $row;
        }
        echo json_encode($massages);
    } else {
        echo json_encode(['error' => 'Erreur lors de la recherche: ' . $stmt->error]);
    }
    $stmt->close();
    $conn->close();
}
?>
