<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['id'])) {
        // Rechercher un membre du personnel par ID
        $id = intval($_GET['id']); // Assurez-vous que l'ID est un entier
        $query = "SELECT * FROM personnel WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $person = $result->fetch_assoc();

        echo json_encode($person);
    } else {
        // Rechercher des membres du personnel en fonction du critère de recherche
        $search = $_GET['search'] ?? '';
        $query = "SELECT * FROM personnel WHERE nom LIKE ? OR profession LIKE ?";
        $stmt = $conn->prepare($query);
        $searchTerm = "%" . $search . "%";
        $stmt->bind_param('ss', $searchTerm, $searchTerm);
        $stmt->execute();
        $result = $stmt->get_result();
        $personnel = [];

        while ($row = $result->fetch_assoc()) {
            $personnel[] = $row;
        }

        echo json_encode($personnel);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action === 'delete') {
            // Supprimer un membre du personnel
            $id = intval($_POST['id']);
            $query = "DELETE FROM personnel WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('i', $id);
            if ($stmt->execute()) {
                echo json_encode(["message" => "Membre du personnel supprimé avec succès."]);
            } else {
                echo json_encode(["error" => "Erreur lors de la suppression du membre du personnel."]);
            }
        } elseif ($action === 'update') {
            // Mettre à jour les informations du personnel
            $id = intval($_POST['id']);
            $nom = $_POST['nom'];
            $profession = $_POST['profession'];
            $photo = $_FILES['photo'] ?? null;

            if ($photo && $photo['error'] === UPLOAD_ERR_OK) {
                $photoName = basename($photo['name']);
                $photoPath = 'uploads/' . $photoName;

                if (move_uploaded_file($photo['tmp_name'], $photoPath)) {
                    // Mettre à jour avec la nouvelle photo
                    $query = "UPDATE personnel SET nom = ?, profession = ?, photo = ? WHERE id = ?";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param('sssi', $nom, $profession, $photoPath, $id);
                } else {
                    echo json_encode(["error" => "Erreur lors du téléchargement de l'image."]);
                    exit();
                }
            } else {
                // Mettre à jour sans changer la photo
                $query = "UPDATE personnel SET nom = ?, profession = ? WHERE id = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('ssi', $nom, $profession, $id);
            }

            if ($stmt->execute()) {
                echo json_encode(["message" => "Membre du personnel mis à jour avec succès."]);
            } else {
                echo json_encode(["error" => "Erreur lors de la mise à jour des informations."]);
            }
        } elseif ($action === 'add') {
            // Ajouter un nouveau membre du personnel
            $nom = $_POST['nom'];
            $profession = $_POST['profession'];
            $photo = $_FILES['imageFile'] ?? null;

            if ($photo && $photo['error'] === UPLOAD_ERR_OK) {
                $photoName = basename($photo['name']);
                $photoPath = 'uploads/' . $photoName;

                if (move_uploaded_file($photo['tmp_name'], $photoPath)) {
                    // Insertion dans la base de données
                    $query = "INSERT INTO personnel (nom, profession, photo) VALUES (?, ?, ?)";
                    $stmt = $conn->prepare($query);
                    $stmt->bind_param('sss', $nom, $profession, $photoPath);

                    if ($stmt->execute()) {
                        echo json_encode(["message" => "Membre du personnel ajouté avec succès."]);
                    } else {
                        echo json_encode(["error" => "Erreur lors de l'ajout du membre du personnel."]);
                    }
                } else {
                    echo json_encode(["error" => "Erreur lors du téléchargement de l'image."]);
                }
            } else {
                // Ajouter sans photo
                $query = "INSERT INTO personnel (nom, profession) VALUES (?, ?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('ss', $nom, $profession);

                if ($stmt->execute()) {
                    echo json_encode(["message" => "Membre du personnel ajouté avec succès."]);
                } else {
                    echo json_encode(["error" => "Erreur lors de l'ajout du membre du personnel."]);
                }
            }
        }
    }
}

$conn->close();
?>
