<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

// Connexion à la base de données
$conn = new mysqli('localhost', 'root', '', 'salon_de_coiffure');

header('Content-Type: application/json');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($conn->connect_error) {
    die(json_encode(["error" => "Erreur de connexion : " . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_reservation = isset($_POST['id_reservation']) ? intval($_POST['id_reservation']) : 0;
    $action = isset($_POST['action']) ? $_POST['action'] : '';

    $stmt = $conn->prepare("SELECT email, etat FROM reservations WHERE id_reservation = ?");
    $stmt->bind_param("i", $id_reservation);
    $stmt->execute();
    $result = $stmt->get_result();
    $reservation = $result->fetch_assoc();
    $email = $reservation['email'];
    $currentStatus = $reservation['etat'];

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'liza.sii.2024@gmail.com';
        $mail->Password   = 'ngsppbhserephwro';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom('liza.sii.2024@gmail.com', 'Liza HAIR & BEAUTY SALON');
        $mail->addAddress($email);

        if ($action === 'validate') {
            $stmt = $conn->prepare("UPDATE reservations SET etat = 'acceptée' WHERE id_reservation = ?");
            $stmt->bind_param("i", $id_reservation);
            $stmt->execute();

            $mail->Subject = "Confirmation de votre réservation";
            $mail->Body    = "Cher client,\n\nVotre réservation a été acceptée. Soyez à l'heure s'il vous plaît.\n\nMerci.";
        } elseif ($action === 'delete') {
            $stmt = $conn->prepare("UPDATE reservations SET etat = 'refusée' WHERE id_reservation = ?");
            $stmt->bind_param("i", $id_reservation);
            $stmt->execute();

            $mail->Subject = "Refus de votre réservation";
            $mail->Body    = "Cher client,\n\nMalheureusement, votre réservation est refusée car vos exigences ne sont pas réunies (date, heure ou personnel choisi non disponible). À très bientôt.\n\nMerci.";
        }

        $mail->send();
        echo json_encode(['message' => $action === 'validate' ? 'Réservation acceptée.' : 'Réservation refusée.']);
    } catch (Exception $e) {
        echo json_encode(["error" => "Erreur lors de l'envoi de l'email."]);
    }

    $stmt->close();
    exit();
}

$search = isset($_GET['search']) ? "%" . $conn->real_escape_string($_GET['search']) . "%" : "%";

$query = "
    SELECT 
        reservations.id_reservation, 
        reservations.date_reservation, 
        reservations.heure_reservation, 
        reservations.adresse_client, 
        reservations.telephone, 
        reservations.email, 
        reservations.etat AS statut,
        utilisateurs.nom_utilisateur,
        prestations.designation, 
        prestations.prix, 
        personnel.nom AS personnel_nom,
        personnel.profession AS personnel_profession
    FROM reservations
    LEFT JOIN utilisateurs ON reservations.id_user = utilisateurs.id
    LEFT JOIN prestations ON reservations.id_prestation = prestations.id
    LEFT JOIN personnel ON reservations.id_personnel = personnel.id
    WHERE 
        utilisateurs.nom_utilisateur LIKE ? 
        OR prestations.designation LIKE ? 
        OR reservations.adresse_client LIKE ? 
        OR reservations.telephone LIKE ?
        OR reservations.email LIKE ?
        OR personnel.nom LIKE ?
        OR personnel.profession LIKE ?
        OR prestations.prix LIKE ? 
        OR reservations.date_reservation LIKE ? 
        OR reservations.heure_reservation LIKE ?
        OR reservations.telephone LIKE ?
        OR reservations.etat LIKE ?
    ORDER BY FIELD(reservations.etat, 'en attente') DESC, reservations.date_reservation DESC
";

$stmt = $conn->prepare($query);
$stmt->bind_param("ssssssssssss", $search, $search, $search, $search, $search, $search, $search, $search, $search, $search, $search, $search);
$stmt->execute();
$result = $stmt->get_result();

$reservations = [];
while ($row = $result->fetch_assoc()) {
    $reservations[] = $row;
}

header('Content-Type: application/json');
echo json_encode($reservations, JSON_PRETTY_PRINT);

$stmt->close();
$conn->close();
?>
