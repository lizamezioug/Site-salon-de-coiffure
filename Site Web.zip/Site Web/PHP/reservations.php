<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    die('Erreur : Vous devez être connecté pour faire une réservation.');
}

$id_user = $_SESSION['user_id'];
$id_prestation = $_POST['id_prestation']; // Utilisez l'ID de prestation envoyé par le formulaire
$id_personnel = isset($_POST['id_personnel']) ? $_POST['id_personnel'] : null; // Ajoutez la gestion de l'ID de personnel
$date_reservation = $_POST['date'];
$heure_reservation = $_POST['heure'];
$telephone = $_POST['telephone'];
$email = $_POST['email'];

if (isset($_POST['vipCheckbox'])) {
    $adresse_client = (isset($_POST['vipCheckbox']) && $_POST['vipCheckbox'] == 'on') 
        ? (isset($_POST['manualAddress']) ? $_POST['manualAddress'] : null)
        : null;
} else {
    $adresse_client = null;
}

$sql = "INSERT INTO reservations (
    id_user,
    id_prestation,
    id_personnel,        -- Ajoutez cette ligne pour stocker l'ID de personnel
    date_reservation,
    heure_reservation,
    adresse_client,
    telephone,
    email
) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "iissssss",
    $id_user,
    $id_prestation,
    $id_personnel,       
    $date_reservation,
    $heure_reservation,
    $adresse_client,
    $telephone,
    $email
);

if ($stmt->execute()) {
    echo "Réservation effectuée avec succès!";
    header('Location: ../HTML/Accueil.html'); // Redirigez vers la page d'accueil ou une page de confirmation
    exit();
} else {
    echo "Erreur : " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
