<?php
session_start();
require 'config.php'; // fichier de connexion à la base de données

// Paramètres d'administrateur
$admin_username = 'admin';
$admin_password = 'admin_password'; // Mettre un mot de passe sécurisé pour l'administrateur

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username_unique'];
    $password = $_POST['password_unique'];

    // Vérification des identifiants admin
    if ($username === $admin_username && $password === $admin_password) {
        $_SESSION['admin'] = true;
        header("Location: ../HTML/accueil_admin.html");
        exit();
    }

    // Vérifier les informations d'identification des utilisateurs normaux
    $sql = "SELECT id, mot_de_passe FROM utilisateurs WHERE nom_utilisateur = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($user_id, $hashed_password);
        $stmt->fetch();

        // Vérification du mot de passe
        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $user_id;
            header("Location: ../HTML/accueil.html");
            exit();
        } else {
            echo "<script>alert('Mot de passe incorrect.');</script>";
        }
    } else {
        echo "<script>alert('Nom d\'utilisateur incorrect.');</script>";
    }
}
?>
