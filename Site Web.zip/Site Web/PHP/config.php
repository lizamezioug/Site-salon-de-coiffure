<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "salon_de_coiffure";

// Créer la connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'La connexion a échoué: ' . $conn->connect_error]);
    exit();
}
?>
