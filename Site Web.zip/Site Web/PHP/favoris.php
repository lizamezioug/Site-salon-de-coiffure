<?php
session_start();
include 'config.php'; // Connexion à la base de données

if (!isset($conn)) {
    die('Erreur de connexion à la base de données.');
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Utilisateur non connecté.']);
    exit;
}

$userId = $_SESSION['user_id']; // ID de l'utilisateur connecté

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    // Suppression d'une prestation des favoris
    $prestationId = intval($_POST['id']);

    // Préparer et exécuter la requête pour supprimer la prestation des favoris de l'utilisateur
    $stmt = $conn->prepare( "DELETE FROM likes WHERE utilisateur_id = ? AND prestation_id = ?");
    $stmt->bind_param('ii', $userId, $prestationId);
    $success = $stmt->execute();

    if ($success) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Erreur lors de la suppression du favori.']);
    }

    $stmt->close();
} else {
    // Récupération des prestations favorites
    $stmt = $conn->prepare('SELECT DISTINCT prestations.* FROM prestations 
                             JOIN likes ON prestations.id = likes.prestation_id 
                             WHERE likes.utilisateur_id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    $favorites = $result->fetch_all(MYSQLI_ASSOC);

    header('Content-Type: application/json');
    echo json_encode($favorites);

    $stmt->close();
}

$conn->close();
?>
