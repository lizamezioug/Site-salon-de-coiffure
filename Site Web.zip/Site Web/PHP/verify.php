<?php
require 'config.php';

if (isset($_POST['email'], $_POST['token'])) {
    $email = $_POST['email'];
    $token = $_POST['token'];

    // Vérifier si le token correspond
    $stmt = $conn->prepare("SELECT * FROM email_verifications WHERE email = ? AND token = ?");
    $stmt->bind_param("ss", $email, $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Récupérer les informations d'inscription depuis les champs de formulaire
        $nom_utilisateur = $_POST['username'] ?? ''; // Utiliser le champ caché
        $mot_de_passe = password_hash($_POST['password'] ?? '', PASSWORD_DEFAULT); // Hachage du mot de passe
        $telephone = $_POST['phone'] ?? ''; // Utiliser le champ caché
        $adresse = $_POST['address'] ?? ''; // Utiliser le champ caché

        // Insérer l'utilisateur dans la table utilisateurs
        $stmt = $conn->prepare("INSERT INTO utilisateurs (nom_utilisateur, mot_de_passe, telephone, email, adresse) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nom_utilisateur, $mot_de_passe, $telephone, $email, $adresse);

        if ($stmt->execute()) {
            // Supprimer l'entrée dans email_verifications après vérification réussie
            $stmt = $conn->prepare("DELETE FROM email_verifications WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();

            // Rediriger vers la page de connexion avec un message de succès
            header('Location: ../HTML/login.html?success=' . urlencode('Inscription réussie, vous pouvez vous connecter.'));
            exit();
        } else {
            header('Location: ../HTML/register.html?error=' . urlencode('Erreur lors de l\'inscription, veuillez réessayer.'));
            exit();
        }
    } else {
        header('Location: ../HTML/register.html?error=' . urlencode('Code de vérification invalide.'));
        exit();
    }
}
?>
