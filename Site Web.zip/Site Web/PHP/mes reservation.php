<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Vous devez être connecté pour voir vos réservations.']);
    exit;
}

$id_user = $_SESSION['user_id'];

// Vérifier si l'utilisateur souhaite annuler une réservation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_reservation'])) {
    $id_reservation = $_POST['id_reservation'];
    
    // Assurez-vous que l'utilisateur peut uniquement annuler ses propres réservations
    $sql_update = "UPDATE reservations SET etat = 'annulée' WHERE id_reservation = ? AND id_user = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ii", $id_reservation, $id_user);

    if ($stmt_update->execute()) {
        echo json_encode(['success' => true, 'message' => 'Réservation annulée avec succès.']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Erreur lors de l\'annulation de la réservation.']);
    }

    $stmt_update->close();
    exit;
}

// Requête SQL pour récupérer les réservations
$sql = "
    SELECT 
        r.id_reservation, 
        p.designation, 
        p.prix, 
        r.date_reservation, 
        r.heure_reservation, 
        r.adresse_client,
        r.telephone,
        r.email,
        r.etat AS statut,
        pe.nom
    FROM 
        reservations r
    JOIN 
        prestations p ON r.id_prestation = p.id
    LEFT JOIN 
        personnel pe ON r.id_personnel = pe.id
    WHERE 
        r.id_user = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_user);
$stmt->execute();
$result = $stmt->get_result();

$reservations = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $reservations[] = $row;
    }
}

// Renvoyer les données en format JSON
echo json_encode($reservations);

$stmt->close();
$conn->close();
?>
