<?php
session_start();
require 'config.php';

// Suppression des erreurs affichées dans la réponse JSON
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    $id = $_POST['id'];

    // Requête pour supprimer l'utilisateur
    $query = "DELETE FROM utilisateurs WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => "Utilisateur supprimé avec succès."]);
    } else {
        echo json_encode(['success' => false, 'message' => "Erreur lors de la suppression de l'utilisateur."]);
    }

    $stmt->close();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['id'])) {
        // Rechercher un membre du utilisateurs par ID
        $id = intval($_GET['id']);
        $query = "SELECT * FROM utilisateurs WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $person = $result->fetch_assoc();

        echo json_encode($person);
        exit;
    } else {
        // Rechercher des membres en fonction du critère de recherche
        $search = $_GET['search'] ?? '';
        $query = "SELECT * FROM utilisateurs WHERE nom_utilisateur LIKE ? OR email LIKE ? OR telephone LIKE ? OR adresse LIKE ?";
        $stmt = $conn->prepare($query);
        $searchTerm = "%" . $search . "%";
        $stmt->bind_param('ssss', $searchTerm, $searchTerm, $searchTerm, $searchTerm);
        $stmt->execute();
        $result = $stmt->get_result();
        $utilisateurs = [];

        while ($row = $result->fetch_assoc()) {
            $utilisateurs[] = $row;
        }

        echo json_encode($utilisateurs);
        exit;
    }
}
?>
