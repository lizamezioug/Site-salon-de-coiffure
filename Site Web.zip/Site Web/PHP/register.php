<?php
require 'config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

if (isset($_POST['username_unique'], $_POST['password_unique'], $_POST['phone_unique'], $_POST['email_unique'], $_POST['address_unique'])) {
    $nom_utilisateur = $_POST['username_unique'];
    $mot_de_passe = password_hash($_POST['password_unique'], PASSWORD_DEFAULT);
    $telephone = $_POST['phone_unique'];
    $email = $_POST['email_unique'];
    $adresse = $_POST['address_unique'];

    // Vérifier si l'email existe déjà
    $stmt = $conn->prepare("SELECT * FROM utilisateurs WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        header('Location: ../HTML/register.html?error=' . urlencode('Email déjà existant.'));
        exit();
    } else {
        // Générer un token à 6 chiffres
        $token = rand(100000, 999999);
       
        // Insérer le token dans la table email_verifications
        $stmt = $conn->prepare("INSERT INTO email_verifications (email, token) VALUES (?, ?)");
        $stmt->bind_param("ss", $email, $token);
        $stmt->execute();

        // Envoi de l'email avec PHPMailer
        $mail = new PHPMailer;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'liza.sii.2024@gmail.com';
        $mail->Password = 'ngsppbhserephwro';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('liza.sii.2024@gmail.com', 'Liza Hair & Beauty Salon');
        $mail->addAddress($email);
        $mail->Subject = 'Vérification de votre email';
        $mail->Body = "Votre code de vérification est : $token.";

        if (!$mail->send()) {
            header('Location: ../HTML/register.html?error=' . urlencode('Erreur lors de l\'envoi de l\'email de vérification.'));
            exit();
        }

        // Afficher le champ pour entrer le code de vérification
        header('Location: ../HTML/register.html?email=' . urlencode($email) . '&username=' . urlencode($nom_utilisateur) . '&password=' . urlencode($_POST['password_unique']) . '&phone=' . urlencode($telephone) . '&address=' . urlencode($adresse));
        exit();
    }
}
?>
