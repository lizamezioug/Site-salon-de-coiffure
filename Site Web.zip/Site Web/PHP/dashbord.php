<?php
header('Content-Type: application/json'); // Assurez-vous que le type de contenu est JSON

// Connexion à la base de données
$host = 'localhost';
$dbname = 'salon_de_coiffure';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Récupération des données pour les utilisateurs et leurs réservations
    $stmt = $pdo->query("SELECT nom_utilisateur, COUNT(*) AS total_reservations
                         FROM utilisateurs u
                         JOIN reservations r ON u.id = r.id_user
                         GROUP BY nom_utilisateur
                         ORDER BY total_reservations DESC");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $usersData = ['labels' => [], 'data' => []];
    foreach ($users as $user) {
        $usersData['labels'][] = $user['nom_utilisateur'];
        $usersData['data'][] = $user['total_reservations'];
    }

    // Récupération des données pour le personnel par profession
    $stmt = $pdo->query("SELECT profession, COUNT(*) AS total
                         FROM personnel
                         GROUP BY profession");
    $personnel = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $personnelData = ['labels' => [], 'data' => []];
    foreach ($personnel as $pers) {
        $personnelData['labels'][] = $pers['profession'];
        $personnelData['data'][] = $pers['total'];
    }


    // Récupération des données pour le personnel le plus demandé
    $stmt = $pdo->query("SELECT p.nom, COUNT(*) AS total_reservations
                         FROM personnel p
                         JOIN reservations r ON p.id = r.id_personnel
                         GROUP BY p.nom
                         ORDER BY total_reservations DESC");
    $personnels = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Préparer les données pour le graphique
    $personnelsData = ['labels' => [], 'data' => []];
    foreach ($personnels as $pers) {
        $personnelsData['labels'][] = $pers['nom'];
        $personnelsData['data'][] = $pers['total_reservations'];
    }



    // Prestations les plus réservées
    $stmt = $pdo->query("SELECT designation, COUNT(*) AS total
                         FROM prestations p
                         JOIN reservations r ON p.id = r.id_prestation
                         GROUP BY designation
                         ORDER BY total DESC");
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $servicesData = ['labels' => [], 'data' => []];
    foreach ($services as $service) {
        $servicesData['labels'][] = $service['designation'];
        $servicesData['data'][] = $service['total'];
    }

    // Réservations par état
    $stmt = $pdo->query("SELECT etat, COUNT(*) AS total
                         FROM reservations
                         GROUP BY etat");
    $reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $reservationsData = ['labels' => [], 'data' => []];
    foreach ($reservations as $res) {
        $reservationsData['labels'][] = $res['etat'];
        $reservationsData['data'][] = $res['total'];
    }

    // Réservations par adresse client
    $stmt = $pdo->query("SELECT adresse_client, COUNT(*) AS total
                         FROM reservations
                         GROUP BY adresse_client");
    $addresses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $addressesData = ['labels' => [], 'data' => []];
    foreach ($addresses as $address) {
        $addressesData['labels'][] = $address['adresse_client'];
        $addressesData['data'][] = $address['total'];
    }

    // Réservations par mois
    $stmt = $pdo->query("SELECT MONTH(date_reservation) AS month, COUNT(*) AS total
                         FROM reservations
                         GROUP BY month");
    $monthlyReservations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $monthlyData = ['labels' => [], 'data' => []];
    foreach ($monthlyReservations as $reservation) {
        $monthlyData['labels'][] = $reservation['month'];
        $monthlyData['data'][] = $reservation['total'];
    }

    // Nombre de prestations par type
    $tables = [
      'coiffure',
      'coupes',
      'maquillage',
      'coloration',
      'epilation_corp',
      'epilation_visage',
      'extension_cils',
      'onglerie',
      'manicure_pedicure',
      'nettoyage_de_peau',
      'tresses',
      'soins_cappilaire',
      'massage'
    ];

    $typeData = ['labels' => [], 'data' => []];

    foreach ($tables as $table) {
      // Prepare and execute SQL statement
      $stmt = $pdo->prepare("SELECT COUNT(*) AS total FROM $table");
      $stmt->execute();
      $count = $stmt->fetch(PDO::FETCH_ASSOC);
  
       // Store the results
      $typeData['labels'][] = ucfirst(str_replace('_', ' ', $table)); // Capitalize the type name
      $typeData['data'][] = $count['total'];
    }




    // Prestations les plus aimées
    $stmt = $pdo->query("SELECT p.designation, COUNT(l.prestation_id) AS total_likes
                        FROM prestations p
                        JOIN likes l ON p.id = l.prestation_id
                        GROUP BY p.designation
                        ORDER BY total_likes DESC");
    $prestations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $prestationsData = ['labels' => [], 'data' => []];
    foreach ($prestations as $prestation) {
      $prestationsData['labels'][] = $prestation['designation'];
      $prestationsData['data'][] = $prestation['total_likes'];
    }













    // Envoyer les données au format JSON
    echo json_encode([
        'users' => $usersData,
        'personnel' => $personnelData,
        'services' => $servicesData,
        'reservations' => $reservationsData,
        'addresses' => $addressesData,
        'monthlyReservations' => $monthlyData,
        'typeData' => $typeData,
        'prestations' => $prestationsData,
        'personnels'=> $personnelsData
        
    ]);

} catch (PDOException $e) {
    // Afficher l'erreur au lieu de l'écrire dans la sortie JSON
    echo json_encode(['error' => 'Erreur : ' . $e->getMessage()]);
}
?>
