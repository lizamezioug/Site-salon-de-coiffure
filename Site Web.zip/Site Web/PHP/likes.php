<?php
session_start();
require 'config.php'; // fichier de connexion à la base de données

header('Content-Type: application/json'); // S'assurer que la réponse est au format JSON

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    http_response_code(401); // Non autorisé
    echo json_encode(['message' => 'Vous devez être connecté pour liker.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$prestation_id = $input['prestation_id'];
$isLiked = $input['isLiked'];
$utilisateur_id = $_SESSION['user_id'];

if ($isLiked) {
    // Ajouter le like dans la base de données
    $sql = "INSERT INTO likes (utilisateur_id, prestation_id) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $utilisateur_id, $prestation_id);
    if ($stmt->execute()) {
        echo json_encode(['message' => 'Liked']);
    } else {
        http_response_code(500); // Erreur interne
        echo json_encode(['message' => 'Erreur lors de l\'ajout du like.']);
    }
} else {
    // Supprimer le like de la base de données
    $sql = "DELETE FROM likes WHERE utilisateur_id = ? AND prestation_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $utilisateur_id, $prestation_id);
    if ($stmt->execute()) {
        echo json_encode(['message' => 'Disliked']);
    } else {
        http_response_code(500); // Erreur interne
        echo json_encode(['message' => 'Erreur lors de la suppression du like.']);
    }
}
?>
