<?php
session_start();
require 'config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];

    // Envoyer un code de réinitialisation
    if ($action == 'send_code') {
        $email = $_POST['email'];

        // Vérifier si l'email existe dans la base de données
        $stmt = $conn->prepare("SELECT id, nom_utilisateur FROM utilisateurs WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id, $username);
            $stmt->fetch();

            // Générer un code de réinitialisation
            $reset_code = substr(str_shuffle("0123456789"), 0, 6);

            // Insérer ou mettre à jour le code de réinitialisation dans la base de données
            $stmt = $conn->prepare("INSERT INTO password_resets (user_id, reset_code) VALUES (?, ?) ON DUPLICATE KEY UPDATE reset_code = ?");
            $stmt->bind_param("iss", $user_id, $reset_code, $reset_code);
            $stmt->execute();

            // Envoyer le code par email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'liza.sii.2024@gmail.com';
                $mail->Password = 'ngsppbhserephwro';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('liza.sii.2024@gmail.com', 'Liza Hair & Beauty Salon');
                $mail->addAddress($email);
                $mail->Subject = 'Réinitialisation de mot de passe';
                $mail->Body = "Bonjour $username,\n\nVoici votre code de réinitialisation : $reset_code";

                $mail->send();
                echo json_encode(['success' => true]);
            } catch (Exception $e) {
                echo json_encode(['success' => false, 'message' => $mail->ErrorInfo]);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Email non trouvé.']);
        }
    }

    // Vérifier le code de réinitialisation
    if ($action == 'verify_code') {
        $reset_code = $_POST['reset_code'];

        $stmt = $conn->prepare("SELECT user_id FROM password_resets WHERE reset_code = ?");
        $stmt->bind_param("s", $reset_code);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Code incorrect.']);
        }
    }

    // Mettre à jour le mot de passe
    if ($action == 'update_password') {
        $reset_code = $_POST['reset_code'];
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

        // Trouver l'utilisateur associé au code
        $stmt = $conn->prepare("SELECT user_id FROM password_resets WHERE reset_code = ?");
        $stmt->bind_param("s", $reset_code);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id);
            $stmt->fetch();

            // Mettre à jour le mot de passe de l'utilisateur
            $stmt = $conn->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?");
            $stmt->bind_param("si", $new_password, $user_id);
            $stmt->execute();

            // Supprimer le code de réinitialisation
            $stmt = $conn->prepare("DELETE FROM password_resets WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();

            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Code incorrect.']);
        }
    }
}
?>
