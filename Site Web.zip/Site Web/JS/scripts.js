document.addEventListener('DOMContentLoaded', function() {
    const stars = document.querySelectorAll('.fa-star');
    stars.forEach(star => {
        star.addEventListener('click', function() {
            stars.forEach(s => s.classList.remove('checked'));
            this.classList.add('checked');
            let previous = this.previousElementSibling;
            while (previous) {
                previous.classList.add('checked');
                previous = previous.previousElementSibling;
            }
        });
    });
});





document.addEventListener('DOMContentLoaded', function() {
    const leftArrow = document.querySelector('.left-arrow');
    const rightArrow = document.querySelector('.right-arrow');
    const cardContainer = document.getElementById('cardContainer');

    const scrollAmount = document.querySelector('.card').clientWidth + 16; // 16 is the margin between cards

    leftArrow.addEventListener('click', () => {
        cardContainer.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    });

    rightArrow.addEventListener('click', () => {
        cardContainer.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    });
});
document.querySelector('.left-arrow').addEventListener('click', function() {
    document.querySelector('#cardContainer').scrollLeft -= 200;
});

document.querySelector('.right-arrow').addEventListener('click', function() {
    document.querySelector('#cardContainer').scrollLeft += 200;
});
