$(document).ready(function() {
    function loadUsers() {
        $.ajax({
            url: '../PHP/utilisateurs.php',
            method: 'GET',
            dataType: 'json',
            success: function(data) {
                console.log("Données récupérées : ", data);
                let userList = $('#user-list');
                userList.empty(); // Vider le conteneur avant d'ajouter les cartes

                data.forEach(function(user) {
                    console.log("Ajout de l'utilisateur : ", user);
                    let userCard = `
                        <div class="col-md-4">
                            <div class="card mb-4">
                                <div class="card-body">
                                    <h5 class="card-title">${user.email}</h5>
                                    <p class="card-text">Téléphone: ${user.phone_number}</p>
                                    <p class="card-text">Adresse: ${user.address}</p>
                                    <button class="btn btn-danger delete-user" data-id="${user.id}">Supprimer</button>
                                </div>
                            </div>
                        </div>
                    `;
                    userList.append(userCard);
                });

                // Ajouter un écouteur d'événements pour les boutons de suppression
                $('.delete-user').on('click', function() {
                    let userId = $(this).data('id');
                    if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
                        $.ajax({
                            url: '../PHP/utilisateurs.php',
                            method: 'POST',
                            data: { id: userId },
                            dataType: 'json',
                            success: function(response) {
                                if (response.success) {
                                    alert('Utilisateur supprimé avec succès');
                                    loadUsers(); // Reload users after deletion
                                } else {
                                    alert('Erreur lors de la suppression de l\'utilisateur');
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error("Erreur lors de la suppression de l'utilisateur : ", error);
                            }
                        });
                    }
                });
            },
            error: function(xhr, status, error) {
                console.error("Erreur lors de la récupération des données : ", error);
                alert("Erreur lors de la récupération des données.");
            }
        });
    }

    loadUsers(); // Chargement initial des utilisateurs
});
