document.addEventListener('DOMContentLoaded', function() {
    // Code existant
    fetch('../PHP/epilation_visage.php')
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('cardContainer');
            const paginationContainer = document.getElementById('paginationContainer');
            const cardsPerPage = 3;
            let currentPage = 1;
            const totalPages = Math.ceil(data.length / cardsPerPage);

            function displayCards(page) {
                container.innerHTML = '';
                const start = (page - 1) * cardsPerPage;
                const end = start + cardsPerPage;
                const cards = data.slice(start, end);

                const row = document.createElement('div');
                row.className = 'row justify-content-center';

                if (cards.length > 0) {
                    cards.forEach(epilation_visage => {
                        const cardWrapper = document.createElement('div');
                        cardWrapper.className = 'card-wrapper col-md-4 d-flex justify-content-center';

                        const card = document.createElement('div');
                        card.className = 'card';

                        const img = document.createElement('img');
                        img.className = 'card-img-top';
                        img.alt = epilation_visage.designation;
                        img.src = epilation_visage.image.includes('http') || epilation_visage.image.includes('www') ? epilation_visage.image : '../PHP/' + epilation_visage.image;

                        const cardBody = document.createElement('div');
                        cardBody.className = 'card-body';

                        const title = document.createElement('h5');
                        title.className = 'card-title';
                        title.textContent = epilation_visage.designation;

                        const priceHeartContainer = document.createElement('div');
                        priceHeartContainer.className = 'price-heart-container d-flex justify-content-between align-items-center';

                        const price = document.createElement('p');
                        price.className = 'card-text';
                        price.textContent = epilation_visage.prix + ' DA';

                        const heart = document.createElement('span');
                        heart.className = 'heart';
                        heart.innerHTML = '&#10084;';
                        if (epilation_visage.isLiked) {
                            heart.classList.add('liked');
                        }

                        heart.onclick = function() {
                            heart.classList.toggle('liked');
                            const isLiked = heart.classList.contains('liked');
                            fetch('../PHP/likes.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    prestation_id: epilation_visage.id,
                                    isLiked: isLiked
                                })
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    console.log('Like enregistré');
                                } else {
                                    console.log('Erreur lors de l\'enregistrement du like');
                                }
                            })
                            .catch(error => console.error('Erreur:', error));
                        };

                        priceHeartContainer.appendChild(price);
                        priceHeartContainer.appendChild(heart);

                        const button = document.createElement('a');
                        button.className = 'btn btn-primary reserve-btn mt-2';
                        button.textContent = 'Réserver';

                        // Ajouter l'ID de la prestation à l'URL lors du clic sur le bouton
                        button.href = `../HTML/Réservations.html?id_prestation=${epilation_visage.id}&prestation_nom=${encodeURIComponent(epilation_visage.designation)}`;

                        cardBody.appendChild(title);
                        cardBody.appendChild(priceHeartContainer);
                        cardBody.appendChild(button);

                        card.appendChild(img);
                        card.appendChild(cardBody);

                        cardWrapper.appendChild(card);
                        row.appendChild(cardWrapper);
                    });

                    while (row.childElementCount < cardsPerPage) {
                        const emptyWrapper = document.createElement('div');
                        emptyWrapper.className = 'col-md-4';
                        row.appendChild(emptyWrapper);
                    }
                }

                container.appendChild(row);
            }

            function createPagination() {
                paginationContainer.innerHTML = '';
                for (let i = 1; i <= totalPages; i++) {
                    const pageDot = document.createElement('span');
                    pageDot.className = 'pagination-dot';
                    pageDot.dataset.page = i;
                    pageDot.onclick = function() {
                        currentPage = i;
                        displayCards(currentPage);
                        updatePagination();
                    };
                    paginationContainer.appendChild(pageDot);
                }
                updatePagination();
            }

            function updatePagination() {
                document.querySelectorAll('.pagination-dot').forEach(dot => {
                    dot.classList.remove('active');
                    if (dot.dataset.page == currentPage) {
                        dot.classList.add('active');
                    }
                });
            }

            function handleKeydown(event) {
                if (event.key === 'ArrowRight' && currentPage < totalPages) {
                    currentPage++;
                    displayCards(currentPage);
                    updatePagination();
                } else if (event.key === 'ArrowLeft' && currentPage > 1) {
                    currentPage--;
                    displayCards(currentPage);
                    updatePagination();
                }
            }

            displayCards(currentPage);
            createPagination();
            document.addEventListener('keydown', handleKeydown);
        })
        .catch(error => console.error('Erreur:', error));


    // Ajout de l'alerte de confirmation pour la déconnexion
    const logoutLink = document.getElementById('logoutLink');
    if (logoutLink) {
        logoutLink.addEventListener('click', function(event) {
            const confirmation = confirm("Êtes-vous sûr de vouloir vous déconnecter ?");
            if (!confirmation) {
                event.preventDefault(); // Annule la déconnexion si l'utilisateur annule la confirmation
            }
        });
    }
});
