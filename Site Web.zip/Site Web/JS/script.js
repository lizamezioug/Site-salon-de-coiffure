$(document).ready(function() {
    function loadCoiffures() {
        $.ajax({
            url: '../PHP/coiffure.php',
            type: 'GET',
            success: function(data) {
                console.log("Données récupérées : ", data);
                let coiffures = data; // Pas besoin de JSON.parse
                console.log("Données JSON parsées : ", coiffures);
                let container = $('#coiffureContainer');
                container.empty(); // Vider le conteneur avant d'ajouter les cartes

                coiffures.forEach(function(coiffure) {
                    console.log("Ajout de la coiffure : ", coiffure);
                    let card = `
                        <div class="card">
                            <img src="${coiffure.image.includes('http') || coiffure.image.includes('www') ? coiffure.image : '../PHP/' + coiffure.image}" alt="${coiffure.designation}">

                            <h2>${coiffure.designation}</h2>
                            <p>${coiffure.prix} DA</p>
                            <button class="deleteBtn" data-id="${coiffure.id}">Supprimer</button>
                            <button class="updateBtn" data-id="${coiffure.id}">Modifier</button>
                        </div>
                    `;
                    container.append(card);
                });
            },
            error: function(xhr, status, error) {
                console.error("Erreur lors de la récupération des données : ", error);
                alert("Erreur lors de la récupération des données.");
            }
        });
    }

    loadCoiffures(); // Initial load

    $(document).on('click', '.deleteBtn', function() {
        let id = $(this).data('id');
        if (confirm('Êtes-vous sûr de vouloir supprimer cette coiffure ?')) {
            $.ajax({
                url: '../PHP/coiffure.php',
                type: 'POST',
                data: { id: id, action: 'delete' },
                success: function(response) {
                    alert(response);
                    loadCoiffures(); // Reload coiffures after deletion
                },
                error: function(xhr, status, error) {
                    console.error("Erreur lors de la suppression de la coiffure : ", error);
                }
            });
        }
    });

    $(document).on('click', '.updateBtn', function() {
        let id = $(this).data('id');
        // Vous pouvez ajouter un formulaire modal pour mettre à jour les informations
        // Par exemple, ouvrez un modal et remplissez les champs avec les données existantes de la coiffure
    });
});


