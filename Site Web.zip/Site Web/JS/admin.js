document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    $('[data-toggle="tooltip"]').tooltip();

    // Dropdown functionality
    $('#servicesDropdown').on('click', function (e) {
        e.preventDefault();
        var $el = $(this).next('.dropdown-menu');
        $el.toggleClass('show');
    });

    // Load content dynamically based on the selected service
    $('.dropdown-item, .nav-link').on('click', function(e) {
        e.preventDefault();
        var target = $(this).data('target');
        if (target) {
            $('.main-content').load(target + '_admin.html');
        }
    });

    // Toggle sidebar for small screens
    $('.btn-sidebar-toggle').on('click', function() {
        $('.sidebar').toggleClass('hidden');
        $(this).find('i').toggleClass('fa-bars fa-times');
    });

    // Close the sidebar by default on small and medium screens
    if (window.innerWidth <= 991) {
        $('.sidebar').addClass('hidden');
    }

    // Adjust sidebar visibility on window resize
    $(window).resize(function() {
        if (window.innerWidth > 991) {
            $('.sidebar').removeClass('hidden');
        } else {
            $('.sidebar').addClass('hidden');
        }
    });
});
